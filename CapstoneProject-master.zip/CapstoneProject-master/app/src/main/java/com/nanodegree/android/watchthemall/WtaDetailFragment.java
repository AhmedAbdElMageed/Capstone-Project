package com.nanodegree.android.watchthemall;

public interface WtaDetailFragment {

    void hideDetailLayout();
}
